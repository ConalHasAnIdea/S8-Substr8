# Wiring citation_validation into both engines

Drop `discovery/citation_validation.py` and `tests/test_citation_validation.py`
into the repo (delete the throwaway `discovery/__init__.py` from this bundle,
your repo already has one). Then make the same edit in BOTH
`discovery/claude_discovery_engine.py` and `discovery/openai_discovery_engine.py`.

## 1. Add the import

```python
from discovery.citation_validation import validate_citations
```

(In the Claude engine, which uses relative imports, `from .citation_validation
import validate_citations` matches the existing style.)

## 2. Replace the validation block

Delete the local `_cite_is_valid` closure and the loop that builds
`normalized_citations` / `fabricated`. Both engines have an identical copy.
Replace with:

```python
        cited = set(parsed.get("evidence_citations", []))
        validation = validate_citations(cited, valid_ids)
        normalized_citations = validation["normalized"]
        fabricated = validation["fabricated"]
```

## 3. Enrich the warning (optional but worth it)

The existing flag/downgrade block can stay exactly as it is; `fabricated` and
`normalized_citations` have the same meaning as before. If you want the flag
to name what was smuggled (recommended, it demos well), swap the flag line
for:

```python
        if fabricated:
            smuggled = sorted({
                uid
                for verdict in validation["details"]
                for uid in verdict.unknown_ids
            })
            flags.append(
                f"fabricated_citations: {fabricated}"
                + (f" (unknown IDs: {smuggled})" if smuggled else "")
            )
```

Everything downstream (strip, downgrade to Needs Clarification, append the
VALIDATION WARNING to reasoning) is untouched.

## Behaviour change to be aware of

One thing IS stricter than before, on purpose: a citation that is pure prose
with no ID in it at all ("as per operator guidance") used to be flagged
fabricated under the old check too, so no change there. But a citation
carrying a real ID PLUS an unknown ID-shaped token now fails where it used to
pass. If a model habitually writes "TKT-1011, cf. TKT-1024" both real, that
still passes. "TKT-1011, cf. TKT-7777" now fails, names TKT-7777 in the flag,
and downgrades the mapping. That is the fix.

## Quick sanity check after wiring

```
pytest tests/test_citation_validation.py -q
pytest -q   # nothing else should have changed
```

Then rerun the injection probe with a payload that smuggles a real ID
alongside the fake one; the guardrail should now hold where it previously
would not have.
